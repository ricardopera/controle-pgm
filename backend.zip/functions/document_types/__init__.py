"""Document types functions package."""
